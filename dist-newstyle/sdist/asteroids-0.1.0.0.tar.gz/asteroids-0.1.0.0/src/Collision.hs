module Collision where

import Types

collide :: Vector -> Float -> Vector -> Float -> Bool -- Checks whether 2 objects (Bullets, enemies or players) collide
collide (Vector x0 y0) s (Vector x1 y1) t =  sqrt ((x0-x1)^(2 :: Int) + (y0-y1)^(2 :: Int)) <= s + t
