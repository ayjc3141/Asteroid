module Types where
import System.Random
data Vector = Vector { x :: Float 
                     , y :: Float 
                     } deriving (Show, Eq)

data Input  = Input { turnLeft  :: Bool 
                    , turnRight  :: Bool
                    , thrust     :: Bool
                    , shoot      :: Bool 
                    } deriving (Show, Eq)

data EnemyType 
            = MeteorEnormous
            | AsteroidLarge
            | AsteroidMedium
            | AsteroidSmall
            | AsteroidMoving
            | SaucerEnormous
            | SaucerSmall
            deriving (Show, Eq)

data Movement = Movement { position :: Vector
                            , velocity :: Vector
                            , rotation :: Float 
                            } deriving (Show, Eq)

data Enemy = Enemy { enemyType      :: EnemyType
                    , enemyMovement  :: Movement 
                    , enemyHitpoints :: Int
                    , enemyAlive     :: Bool
                    , enemyHitbox    :: Float
                    } deriving (Show, Eq)

data Player = Player { playerNr         :: Int
                        , playerMovement   :: Movement
                        , playerAlive      :: Bool
                        , playerInput      :: Input
                        , playerHitbox     :: Float 
                        } deriving (Show, Eq)

data BulletType = Friend | Foe
                    deriving (Show, Eq)

data Bullet = Bullet { bulletMovement :: Movement
                        , bulletType     :: BulletType 
                        , bulletHitbox   :: Float
                        } deriving (Show,Eq)

data AnimationType = Death | Explosion deriving (Show, Eq)

data Animation = Animation { animationPosition  :: Vector
                            , duration           :: Float
                            , animationType      :: AnimationType
                            } deriving (Show, Eq)

data GameState = GameState { players :: [Player]
                            , enemies :: [Enemy]
                            , bullets :: [Bullet]
                            , effects :: [Animation]
                            , score   :: Int
                            , lives   :: Int
                            , wave    :: Int
                            , paused  :: Bool
                            , rng     :: StdGen
                            } deriving (Show)

data HighScore = HighScore { playerName  :: String
                            , playerScore :: Int
                            } deriving (Show, Eq)

instance Ord HighScore where
    compare hs1 hs2 = compare (playerScore hs1) (playerScore hs2)
