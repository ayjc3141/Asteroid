module Main (main) where
import Graphics.Gloss.Interface.IO.Game
import Types 
import Collision 
import Input

main :: IO ()
main = playIO  
                (InWindow "Asteroid" (800,800) (100,100))
                (makeColor 0 0 0 1)
                60
                ()
                (\_ -> pure (Text "BALLS"))
                (\_ state -> pure state)
                (\_ state -> pure state)
